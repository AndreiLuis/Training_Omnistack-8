# Training_Omnistack-8
Nesta versão do Omnistack, foi criado o "Tindev", que é um Tinder para desenvolvedores
